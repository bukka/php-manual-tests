<?php

declare(strict_types=1);

namespace App\Presenters;

use Nette;
use function assert;


final class HomePresenter extends Nette\Application\UI\Presenter
{
	protected function createComponentForm(): Nette\Application\UI\Form
	{
		$form = new Nette\Application\UI\Form;
		$form->allowCrossOrigin();

		$form->addMultiUpload('files', 'Files');
//			->setRequired();

		$form->addSubmit('send', 'Send');

		// nahrání do temp
		$form->onSuccess[] = [$this, 'formSuccess'];

		return $form;
	}


	public function formSuccess(Nette\Application\UI\Form $form, \stdClass $values = null): void
	{
		//@elkropac, added session_write_close
		session_write_close();
		
		$path = __DIR__ . DIRECTORY_SEPARATOR . join(DIRECTORY_SEPARATOR, ['..', 'fotky']) . DIRECTORY_SEPARATOR;

		if(!is_dir($path))
		{
			mkdir($path, 0777);
		}

		foreach($form->getUntrustedValues()->files as $file)
		{
			assert($file instanceof \Nette\Http\FileUpload);

			// Přeskočit neobrázky
			if($file->isOk() && $file->isImage())
			{
				$filename = $path . $file->getSanitizedName();

				// přesunutí obrázku
				$file->move($filename);

				$image = Nette\Utils\Image::fromFile($file->getTemporaryFile());

				// Úprava obrázku
				$image->resize(800, null);

				// Uložení zpracované kopie
				$image->save($path . '__upraveny' . $file->getSanitizedName());

				unlink($filename);
			}
		}

		$this->getPresenter()->flashMessage('Files uploaded', 'success');
		$this->getPresenter()->redirect('this');
	}
}
